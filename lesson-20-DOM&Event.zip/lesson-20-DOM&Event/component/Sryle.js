const modal = document.querySelector('.modal');
const verlay = document.querySelector('.overlay');
const btnCloseModal = document.querySelector('.close-modal');
const btnsOpenModal =document.querySelector('.open-modal');
console.log(btnsOpenModal);